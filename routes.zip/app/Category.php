<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Category extends Model
{
    protected $fillable = ['title'];
    protected $table = 'categories';

    public function subCategories()
    {
        return $this->hasMany(Sub_category::class, 'cat_id');
    }

    public function user()
    {
        return $this->belongsToMany(User::class);
    }


    public function post()
    {
        return $this->belongsTo(Post::class);
    }



}
