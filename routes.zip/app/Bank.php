<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Bank extends Model
{
  protected $table='banks';
    protected $fillable=['name','account_name','account_number','iban_number','user_id','course_id'];

    public function User()
    {
        return $this->belongsTo(User::class, 'user_id');
    }

    public function course()
    {
        return $this->belongsTo(course::class, 'course_id');
    }
}
