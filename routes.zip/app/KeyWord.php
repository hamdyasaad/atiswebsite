<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class KeyWord extends Model
{
    protected $fillable = ['title'];
    protected $table = 'key_words';

    public function Services()
    {
        return $this->hasMany(Service::class, 'key_id');
    }
}
