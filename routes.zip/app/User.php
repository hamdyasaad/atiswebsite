<?php

namespace App;

use Illuminate\Notifications\Notifiable;
use Illuminate\Foundation\Auth\User as Authenticatable;
use Mockery\Matcher\Not;
use Tymon\JWTAuth\Contracts\JWTSubject;



class User extends Authenticatable implements JWTSubject
{
    use Notifiable;

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $table ='users';
    protected $fillable = ['first_name', 'last_name', 'age','gender','country','city','address1','address2','email','mobile','payment','method','token_api','password'];

    /**
     * The attributes that should be hidden for arrays.
     *
     * @var array
     */
    protected $hidden = ['password', 'remember_token',];

    public function Services()
    {
        return $this->hasMany(Service::class, 'owner_id');
    }

     public function Ucourses()
    {
        return $this->hasMany(Course::class, 'owner_id');
    }
     public function Courses()
    {
    return $this->belongsToMany('App\Course','reviews')->withTimestamps();
    }

    public function Reservecourse()
    {
    return $this->belongsToMany('App\Course','reserved_courses')->withTimestamps();
    }
    public function UTransfer()
    {
        
    return $this->belongsToMany('App\Course','transfers')->withTimestamps();
    }


    public function Reviews()
    {
        return $this->belongsToMany(Course::class, 'reviews', 'user_id', 'course_id');
    }

    public function SMessages()
    {
        return $this->hasMany(Message::class, 'sender_id');
    }

    public function RMessages()
    {
        return $this->hasMany(Message::class, 'receiver_id');
    }

    public function SNotification()
    {
        return $this->hasMany(Notification::class, 'sender_id');
    }

    public function RNotification()
    {
        return $this->hasMany(Notification::class, 'receiver_id');
    }

    public function Favs()
    {
        return $this->belongsToMany(Service::class, 'favourites', 'user_id', 'service_id');
    }

    public function Banks()
    {
        return $this->hasMany(Bank::class, 'user_id');
    }

    public function getJWTIdentifier()
    {
        return $this->getKey();
    }
    public function getJWTCustomClaims()
    {
        return [];
    }
}
