<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Eye extends Model
{
    protected $table='eyes';
    protected $fillable=['ardesc','endesc'];
}
