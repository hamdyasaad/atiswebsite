<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Service_images extends Model
{
    protected $fillable = ['service_id','title'];
    protected $table = 'service_images';
    public function Service(){
        return $this->belongsTo(Service::class,'service_id');
    }
}
