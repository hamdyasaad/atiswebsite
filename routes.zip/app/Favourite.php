<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Favourite extends Model
{
    protected $table = 'favourites';
    protected $fillable = ['service_id', 'user_id'];

    public function Users()
    {
        return $this->belongsToMany(User::class, 'favourites', 'service_id', 'user_id');
    }

}
