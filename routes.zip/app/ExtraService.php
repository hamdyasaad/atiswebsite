<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ExtraService extends Model
{
    protected $fillable = ['status', 'service_id', 'time', 'title', 'salary'];
    protected $table = 'extra_services';

    public function Service()
    {
        return $this->belongsTo(Service::class, 'service_id');
    }
}
