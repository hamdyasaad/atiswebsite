<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ReservedCourses extends Model
{
    protected $table='reserved_courses';
    protected $fillable=['bank_name','account_name','account_number','iban_number','user_id','course_id'];
}
