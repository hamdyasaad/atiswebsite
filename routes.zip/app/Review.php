<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use willvincent\Rateable\Rateable;



class Review extends Model

{
	    use Rateable;


    protected $table='reviews';
    protected $fillable=['name','review','rating','user_id','course_id'];
}


