<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use App\Image ;
use Validator;
use App\Setting;

use App\Partner;

class PartnerController extends Controller
{
    public function show()
    {
        $setting = Setting::orderBy('id','asc')->first();
    	$partners = Partner::all();
    	return view('partner.show',compact('partners','setting'));
    }

    public function deleteService($id){
        Partner::destroy($id);
        return back();
    }

    public function add(){
        $setting = Setting::orderBy('id','asc')->first();

        
        
        return view('partner.create',compact('setting'));
    }

    public function store(Request $request){
        if (Auth::check()){

             $validator = Validator::make($request->all(),[
                    'img'       => 'required',
                    

                 ]);

                 if($validator->fails())
                    {
                        
                        return redirect()->back();       
                    }

                    $partners = new Partner;
                    $images           = $request['img'];

                      if($images)
                {
                
                
                
                    $img_name = rand(0, 999) . '.' . $images->getClientOriginalExtension();
                    $images->move(base_path('public/dash2/assets/img'), $img_name);
                    
             

                
                $partners->img = $img_name;
            }
            $partners->save();
            if($partners){
                                        return redirect()->back();       

            }
 }          }
}
