<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Eye;
use App\Setting;
use Validator;


class EyeController extends Controller
{
     public function show(){
        $setting = Setting::orderBy('id','asc')->first();

     	$visions = Eye::all();
        return view('home.eye',compact('visions','setting'));
    }


     public function showadmin(){
        $setting = Setting::orderBy('id','asc')->first();

     	     	$visions = Eye::all();

        return view('visions.eye',compact('visions','setting'));
    }

     public function edit($id){
        $setting = Setting::orderBy('id','asc')->first();
        $vision = Eye::find($id);
        return view('visions.edit',compact('vision','setting'));
    }

     public function update(Request $request,$id)
    {
        Eye::find($id)->update([
            'endesc'=>$request->input('endesc'),
            'ardesc'=>$request->input('ardesc'),
            



        ]);


        return redirect()->back();
    }
}
