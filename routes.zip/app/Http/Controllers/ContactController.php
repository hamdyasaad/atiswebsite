<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Setting;
use App\Contact;

class ContactController extends Controller
{
    public function show()
    {
        $setting = Setting::orderBy('id','asc')->first();
    	return view('home.contact',compact('setting'));
    }

    public function storeEmail(Request $request){

            $contacts = Contact::create([
                'fname'=>$request->input('fname'),
                'lname'=>$request->input('lname'),
                'email'=>$request->input('email'),
                'comment'=>$request->input('comment'),
                
            


            ]);

            if($contacts){
                return redirect()->route('User.showweb');

            }
        
        return back();
    }}

