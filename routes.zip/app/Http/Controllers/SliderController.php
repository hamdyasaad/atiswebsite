<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Setting;
use App\Slider;
use Validator;


use Illuminate\Support\Facades\Auth;

class SliderController extends Controller
{
    public function show()
    {

        $setting = Setting::orderBy('id','asc')->first();
        $sliders = Slider::all();
        
        return view('sliders.show', ['sliders'=> $sliders ,'setting'=>$setting]);
    }

    public function deleteService($id){
        Slider::destroy($id);
        return back();
    }

     public function edit($id){

        $setting = Setting::orderBy('id','asc')->first();
        
        $slider = Slider::find($id);
        return view('sliders.edit',compact('slider','setting'));
    }

     public function update(Request $request,$id)
    {
        
        
        

           if (Auth::check()){

            $sliders = Slider::find($id);

        if($sliders)
        {

            $validator = Validator::make($request->all(),[
                    'img'       => 'required',
                    'endesc'       => 'required',
                    'ardesc'       => 'required',
                   
                    

                 ]);

                 if($validator->fails())
                    {
                        
                        return redirect()->back();       
                    }
            
            $sliders->endesc =$request['endesc'];
            $sliders->ardesc =$request['ardesc'];
            $sliders->url =$request['url'];
           
            
                
          $images           = $request['img'];

                      if($images)
                {
                
                
                
                    $img_name = rand(0, 999) . '.' . $images->getClientOriginalExtension();
                    $images->move(base_path('public/dash2/assets/img'), $img_name);
                    
             

                
                $sliders->img = $img_name;
            }
            $sliders->save();
            if($sliders){
                return redirect()->route('Slider.show');

            }
        }
        return back();
    	}
	}

	public function add(){
        $setting = Setting::orderBy('id','asc')->first();
        
        

        return view('sliders.create',['setting'=>$setting]);
    }

    public function store(Request $request){
        if (Auth::check()){

            $validator = Validator::make($request->all(),[
                    'img'       => 'required',
                    'endesc'       => 'required',
                    'ardesc'       => 'required',
                    
                    
                    

                 ]);

                 if($validator->fails())
                    {
                        
                        return redirect()->back();       
                    }
            $sliders = new Slider;
            
            $sliders->endesc =$request['endesc'];
            $sliders->ardesc =$request['ardesc'];
            $sliders->url =$request['url'];
            
                
          $images           = $request['img'];

                      if($images)
                {
                
                
                
                    $img_name = rand(0, 999) . '.' . $images->getClientOriginalExtension();
                    $images->move(base_path('public/dash2/assets/img'), $img_name);
                    
             

                
                $sliders->img = $img_name;
            }
            $sliders->save();
            if($sliders){
                return redirect()->route('Slider.show');

            }
        }
        return back();
    }
}
