<?php

namespace App\Http\Controllers;
use App\Service;
use App\Course;
use App\User;
use App\Contact;
use App\Review;
use App\City;
use App\Slider;
use App\Partner;
use App\Setting;
use App\Event;
use App\ReservedCourses;
use DB;
use Hash;
use Validator;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class AdminController extends Controller
{
    public function userLogin()
    {
        $users =User::all();
        $setting = Setting::orderBy('id','asc')->first();
        return view ('auth.login',compact('setting','users'));
    }
    
     public function showServices($id){

        $setting = Setting::orderBy('id','asc')->first();
        $users = User::all();
        $services = ReservedCourses::where('user_id',$id)->get();
        return view('services.showcourse', ['services'=>$services,'users'=> $users,'setting'=>$setting]);



    }

    public function checkLogin(Request $request)
    {
         if (Auth::attempt(['email' => $request['email'], 'password' => $request['password'], 'type' =>'user'])) {
            return redirect()->route('User.showweb');
        }else{
            return back();
        }

    }
    public function edituser(Request $request)
    {
           $setting = Setting::orderBy('id','asc')->first();
                          $id=$request->id;

    $user = User::find($request->id);
    $cities = City::all();
        if ($id!=null) {

               return view('home.editaccount',compact('user','setting','cities','id'));

       }else{
        return redirect()->route('Admin.myaccount')->with(['fail' => 'تم فقد الصفحة لتأخرك برجاء الاختيار مجددا ']);
       }


    }


    public function getLogin()
    {
        return view('admin_login');
    }
    public function logout(Request $request) {
        Auth::logout();
        return redirect()->route('ADMIN_LOGIN');
    }

    public function userlogout(Request $request) {
        Auth::logout();
        return redirect()->route('USER_LOGIN');
    }


    public function dashboard(){
        $setting = Setting::orderBy('id','asc')->first();
        return view('main',compact('setting'));
    }
    public function postLogin(Request $request){
//        dd($request->all());
        if (Auth::attempt(['email' => $request['email'], 'password' => $request['password'], 'type' =>'admin'])) {
            return redirect()->route('dashboard');
        }else{
            return back();
        }
    }
    
    public function myaccount()
    {
                if (Auth::check()){

        
        $setting = Setting::orderBy('id','asc')->first();
        return view('home.myaccount', ['setting'=>$setting]);
                }
                else
                {
                    $setting = Setting::orderBy('id','asc')->first();
        return view('auth.login', ['setting'=>$setting]);
                }
        
    }
    public function form()
    {
        $setting = Setting::orderBy('id','asc')->first();
        return view('users.form',compact('setting'));
    }

    public function insert(Request $request)
    {

            $user = User::create([
                'first_name' => $request->input('first_name'),
               'last_name' => $request->input('last_name'),
               'email' => $request->input('email'),
                'password' => Hash::make($request->input('password')),
                'age' => $request->input('age'),
                'gender' => $request->input('gender'),
                'mobile' => $request->input('mobile'),
                'address1' => $request->input('address1'),
                'address2' => $request->input('address2'),
                'country' => $request->input('country'),
             'city' => $request->input('city'),

            ]);

                       return redirect()->route('users.basic', ['user'=> $user]);



    }

    public function show()
    {
        $setting = Setting::orderBy('id','asc')->first();

            $users = User::all();

            return view('users.show', ['users'=> $users,'setting'=>$setting]);
    }
    
    public function add(){
        $setting = Setting::orderBy('id','asc')->first();
            $cities = City::all();


        return view ('users.create',compact('setting','cities'));

    }

    public function add_admin(){
        $setting = Setting::orderBy('id','asc')->first();
    $cities = City::all();

        return view ('admins.create',compact('setting','cities'));

    }

    public function store(Request $request){
        if (Auth::check()){
            $user = new User;
               $user->first_name = $request['first_name'];
        $user->last_name = $request['last_name'];
        $user->email = $request['email'];
        $user->password = Hash::make($request['password']);
        $user->age = $request['age'];
        $user->gender = $request['gender'];
        $user->country = $request['country'];
        $user->city = $request['city'];
        $user->address1 = $request['address1'];
        $user->address2 = $request['address2'];
        $user->mobile = $request['mobile'];

        $user->save();


                
                        if($user){
                return redirect()->route('Admin.show');

            }
        }
        return back();
    }
    public function Adminstore(Request $request){
        if (Auth::check()){
            $user = new User;
               $user->first_name = $request['first_name'];
        $user->last_name = $request['last_name'];
        $user->email = $request['email'];
        $user->password = Hash::make($request['password']);
        $user->age = $request['age'];
        $user->gender = $request['gender'];
        $user->country = $request['country'];
        $user->city = $request['city'];
        $user->address1 = $request['address1'];
        $user->address2 = $request['address2'];
        $user->mobile = $request['mobile'];
        $user->type = 'admin';

        $user->save();


                
                        if($user){
                return redirect()->route('Admin.show');

            }
        }
        return back();
    }
//
//    public function destroy($id){
//        $user = User::find($id);
//        $user->delete();
//
//        return Redirect()->route('Admin.show');
//
//    }

    public function deleteUser($id){
        User::destroy($id);
        return back();
    }
    
     public function updateuser(Request $request,$id)
    {
         User::find($id)->update([
            'first_name' => $request->input('first_name'),
               'last_name' => $request->input('last_name'),
               'email' => $request->input('email'),
                'password' => $request->input('password'),
                'age' => $request->input('age'),
                'gender' => $request->input('gender'),
                'mobile' => $request->input('mobile'),
                'address1' => $request->input('address1'),
                'address2' => $request->input('address2'),
                'country' => $request->input('country'),
             'city' => $request->input('city'),
        ]);


        return redirect()->route('Admin.myaccount');
    }
    
    public function update(Request $request,$id)
    {
         User::find($id)->update([
            'first_name' => $request->input('first_name'),
               'last_name' => $request->input('last_name'),
               'email' => $request->input('email'),
                'password' => $request->input('password'),
                'age' => $request->input('age'),
                'gender' => $request->input('gender'),
                'mobile' => $request->input('mobile'),
                'address1' => $request->input('address1'),
                'address2' => $request->input('address2'),
                'country' => $request->input('country'),
             'city' => $request->input('city'),
        ]);


        return redirect()->route('Admin.show');
    }
    public function edit($id){
        $setting = Setting::orderBy('id','asc')->first();
    $user = User::find($id);
        $cities = City::all();

        return view('users.edit',compact('user','setting','cities'));
    }
    
    

    public function index(){
        
        $setting = Setting::orderBy('id','asc')->first();
        $users = User::whereType('admin')->get();
        return view('admins.show', ['users'=> $users,'setting'=>$setting]);
    }


      public function showweb(){
        $users =User::all();
        $setting = Setting::orderBy('id','asc')->first();
        $partners = Partner::all();
        $sliders = Slider::all();
        $events = Event::orderBy('id')->paginate(3);
        $courses   = Course::orderBy('id','desc')->where('suspensed',0)->paginate(2);       
        $count = Review::all();
      
        return view('home.index',['courses'=> $courses,'count'=>$count,'sliders'=>$sliders,'partners'=>$partners,'setting'=>$setting,'users'=>$users,'events'=>$events]);
    }

     public function storeEmail(Request $request){

            $contacts = Contact::create([
                'email'=>$request->input('email'),
                
            


            ]);

            if($contacts){
                return redirect()->route('User.showweb');

            }
        
        return back();
    }

    public function userRegister()
    {
        $cities = City::all();
        $setting = Setting::orderBy('id','asc')->first();
        return view('home.user_register',compact('setting','cities'));
    }

     public function storeUser(Request $request){
        $validator = Validator::make($request->all(),[
                    'first_name'       => 'required',
                    'last_name'       => 'required',
                    'email'       => 'required',
                    'password'       => 'required',
                    'age'       => 'required',
                    'gender'       => 'required',
                    'country'       => 'required',
                    'city'       => 'required',
                    'address1'       => 'required',
                    'address2'       => 'required',
                    'mobile'       => 'required',
                    

                 ]);

                 if($validator->fails())
                    {
                        
                        return redirect()->back();       
                    }

        $user = new User ;
        $user->first_name = $request['first_name'];
        $user->last_name = $request['last_name'];
        $user->email = $request['email'];
        $user->password = Hash::make($request['password']);
        $user->age = $request['age'];
        $user->gender = $request['gender'];
        $user->country = $request['country'];
        $user->city = $request['city'];
        $user->address1 = $request['address1'];
        $user->address2 = $request['address2'];
        $user->mobile = $request['mobile'];
        $user->save();

    if($user){
                return redirect()->route('User.showweb');

            }
        
        return back();
            
    }


    













}
