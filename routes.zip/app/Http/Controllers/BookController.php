<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

use App\Book;
use App\Setting;
use Validator;


class BookController extends Controller
{
     public function show(){
        $setting = Setting::orderBy('id','asc')->first();

     	$books = Book::orderBy('id')->paginate(2);
        return view('home.book',compact('books','setting'));
    }


     public function showadmin(){
        $setting = Setting::orderBy('id','asc')->first();

      	$books = Book::all();

        return view('books.show',compact('books','setting'));
    }
    
     public function deleteBook($id){
        Book::destroy($id);
        return back();
    }
    
    public function edit($id){

        $setting = Setting::orderBy('id','asc')->first();
        $book = Book::find($id);
        return view('books.edit',compact('book','setting'));
    }
    
    
     public function update(Request $request,$id)
    {
           if (Auth::check()){

            $books = Book::find($id);

        if($books)
        {

            $validator = Validator::make($request->all(),[
                    'name'       => 'required',
                    'date'       => 'required',
                    'file'       => 'required|mimes:png,jpeg,jpg,pdf,doc,docx',
                    'by'       => 'required',
                    'img'       => 'required',
                  
                    

                 ]);

                 if($validator->fails())
                    {
                        
                        return redirect()->back();       
                    }
            
            $books->name =$request['name'];
            $books->by =$request['by'];
            $books->date =$request['date'];
            
                
          $images           = $request['img'];
          $file           = $request['file'];
                      if($images)
                {
                
                    $img_name = rand(0, 999) . '.' . $images->getClientOriginalExtension();
                    $images->move(base_path('public/dash2/assets/img'), $img_name);
                $books->img = $img_name;
            }

                      if($file)
                {
                    $img_name = rand(0, 999) . '.' . $file->getClientOriginalExtension();
                    $file->move(base_path('public/dash2/assets/img'), $img_name);
                    
             

                
                $books->file = $img_name;
            }
            
            $books->save();
            if($books){
                return redirect()->route('Book.showadmin');

            }
        }
        return back();
    }
}

public function add(){
        $setting = Setting::orderBy('id','asc')->first();
        

        return view('books.create',['setting'=>$setting]);
    }
    
    public function store(Request $request){
        

            $validator = Validator::make($request->all(),[
                    'name'       => 'required',
                    'date'       => 'required',
                    'img'       => 'required',
                    'file'       => 'required|mimes:png,jpeg,jpg,pdf,doc,docx',
                    'by'       => 'required',
                 
                    

                 ]);

                 if($validator->fails())
                    {
                        
                        return redirect()->back();       
                    }
            $books = new Book;
            $books->name =$request['name'];
            $books->by =$request['by'];
            $books->date =$request['date'];
           
                
          $images           = $request['img'];
          $file           = $request['file'];


                      if($images)
                {
                
                
                
                    $img_name = rand(0, 999) . '.' . $images->getClientOriginalExtension();
                    $images->move(base_path('public/dash2/assets/img'), $img_name);
                    
             

                
                $books->img = $img_name;
            }

                      if($file)
                {
                
                
                
                    $img_name = rand(0, 999) . '.' . $file->getClientOriginalExtension();
                    $file->move(base_path('public/dash2/assets/img'), $img_name);
                    
             

                
                $books->file = $img_name;
            }
            

            $books->save();
            if($books){
                return redirect()->route('Book.showadmin');

            }
        
        return back();
    }



}
