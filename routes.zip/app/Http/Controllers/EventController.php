<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

use App\Event;
use App\Setting;
use Validator;


class EventController extends Controller
{
     public function show(){
        $setting = Setting::orderBy('id','asc')->first();

        $events   = Event::orderBy('id')->paginate(3);       
        return view('home.events',compact('events','setting'));
    }
    
    public function showevents()
    {

        $setting = Setting::orderBy('id','asc')->first();
        $events = Event::all();
        return view('events.show', ['events'=> $events ,'setting'=>$setting]);
    }
    
     public function deleteEvent($id){
        Event::destroy($id);
        return back();
    }
    
    public function edit($id){

        $setting = Setting::orderBy('id','asc')->first();
        $event = Event::find($id);
        return view('events.edit',compact('event','setting'));
    }
    
    public function update(Request $request,$id)
    {
           if (Auth::check()){

            $events = Event::find($id);

        if($events)
        {

            $validator = Validator::make($request->all(),[
                    'name'       => 'required',
                    'ardesc'       => 'required',
                    'endesc'       => 'required',
                    'date'       => 'required',
                 ]);

                 if($validator->fails())
                    {
                        return redirect()->back();       
                    }
            $events->name =$request['name'];
            $events->ardesc =$request['ardesc'];
            $events->endesc =$request['endesc'];
            $events->date =$request['date'];
            $events->save();
            if($events){
                return redirect()->route('Event.showevent');
            }
        }
        return back();
    }
}

public function add(){
        $setting = Setting::orderBy('id','asc')->first();
        

        return view('events.create',['setting'=>$setting]);
    }

    public function store(Request $request){
    
            $validator = Validator::make($request->all(),[
                    'name'       => 'required',
                    'ardesc'       => 'required',
                    'endesc'       => 'required',
                    'date'       => 'required',
                 ]);

                 if($validator->fails())
                    {
                        
                        return redirect()->back();       
                    }
            $events = new Event;
            $events->name =$request['name'];
            $events->ardesc =$request['ardesc'];
            $events->endesc =$request['endesc'];
            $events->date =$request['date'];
           
            $events->save();
            if($events){
                return redirect()->route('Event.showevent');

            }
        
        return back();
    }



}
