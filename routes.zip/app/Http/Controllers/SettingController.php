<?php

namespace App\Http\Controllers;

use App\Setting;
use Illuminate\Http\Request;
use Validator;

class SettingController extends Controller
{
    public function show()
    {
        $setting = Setting::orderBy('id','asc')->first();
        return view('settings.show', ['setting'=> $setting]);
    }


    public function edit($id){
        $setting = Setting::find($id);
        return view('settings.edit',compact('setting'));
    }
    public function update(Request $request,$id)
    {
    

        $setting = Setting::find($id);
        if($setting)
        {
            $validator = Validator::make($request->all());

            if($validator->fails())
                    {
                        
                        return redirect()->back();       
                    }

            $setting->site_name      = $request['site_name'];
            $setting->privacies   = $request['privacies'];
            $setting->about_site      = $request['about_site'];
            $setting->phone      = $request['price'];
            $setting->email      = $request['email'];
            $setting->enaddress      = $request['enaddress'];
            $setting->facebook      = $request['facebook'];
            $setting->twitter      = $request['twitter'];
            $setting->inst      = $request['inst'];
            $setting->whats      = $request['whats'];
            $setting->google      = $request['google'];
            $setting->youtube      = $request['youtube'];
            $setting->linked      = $request['linked'];

            
            $images = $request['site_logo'];

                  if($images)
                {
                
                
                
                    $img_name = rand(0, 999) . '.' . $images->getClientOriginalExtension();
                    $images->move(base_path('public/dash2/assets/img'), $img_name);
                    
             

                
                $setting->site_logo = $img_name;
            }
            $setting->save();
            if($setting){
                return redirect()->route('Setting.show');     

            }
    }
}
}
