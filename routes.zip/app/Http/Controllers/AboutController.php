<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\About;
use App\Setting;

class AboutController extends Controller
{
     public function show(){
        $setting = Setting::orderBy('id','asc')->first();

     	$abouts = About::all();
        return view('home.about',compact('abouts','setting'));
    }


     public function showadmin(){
        $setting = Setting::orderBy('id','asc')->first();

     	     	$abouts = About::all();

        return view('about.about',compact('abouts','setting'));
    }

     public function edit($id){
        $setting = Setting::orderBy('id','asc')->first();
        $about = About::find($id);
        return view('about.edit',compact('about','setting'));
    }

     public function update(Request $request,$id)
    {
        About::find($id)->update([
            'endesc'=>$request->input('endesc'),
            'ardesc'=>$request->input('ardesc'),
            



        ]);


        return redirect()->back();
    }
}
