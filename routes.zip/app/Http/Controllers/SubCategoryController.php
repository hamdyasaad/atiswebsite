<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Category;
use App\Sub_category;

use Illuminate\Support\Facades\Auth;





class SubCategoryController extends Controller
{
    public function show()
    {

        $sub_categories = Sub_category:: all();
        return view('sub_category.show', ['sub_categories'=>$sub_categories]);
    }
    public function add(){
        $categories = Category::all();

        return view ('sub_category.create',['categories'=>$categories]);

    }
    public function store(Request $request){
        if (Auth::check()){
            $sub_category = Sub_category::create([
                'title' => $request->input('title'),
                'cat_id' => $request->input('cat_id')

            ]);

            if($sub_category){
                return redirect()->route('SubCategory.show');

            }
        }
        return back();
    }
    public function deleteSubcategory($id){
        Sub_category::destroy($id);
        return back();
    }
    public function edit($id){
        $categories = Category::all();


        $sub_category = Sub_category::find($id);
        return view('sub_category.edit',compact('sub_category','categories'));
    }
       public function update(Request $request,$id)
    {
        Sub_category::find($id)->update([
            'title'=>$request->input('title')

        ]);


        return redirect()->route('SubCategory.show');
    }


}
