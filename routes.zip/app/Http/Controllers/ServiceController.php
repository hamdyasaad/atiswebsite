<?php

namespace App\Http\Controllers;

use App\KeyWord;
use App\Course;

use App\Category;
use App\Review;
use App\Sub_category;
use App\User;
use App\Bank;
use App\Slider;
use App\Setting;
use App\Transfer;
use App\ReservedCourses;
use Validator;
use DB;
use Mail;

use AppMailSendMailable;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;




class ServiceController extends Controller
{
    public function show()
    {

        $setting = Setting::orderBy('id','asc')->first();
        $services = Course::all();
        $users = User::all();
        return view('services.show', ['services'=> $services ,'users'=>$users,'setting'=>$setting]);
    }

    public function Suspendshow($id)
    {
                 
                $upmember = Course::find($id);

            if(Input::has('suspensed'))
            {
              if($upmember->suspensed == 0)
              {
                DB::table('courses')->where('id',$id)->update(['suspensed' => 1]);
                return back();
              }
              else 
              {
                DB::table('courses')->where('id',$id)->update(['suspensed' => 0]);
                return back();
              }
            }
        }

    

    


    public function deleteService($id){
        Course::destroy($id);
        return back();
    }

    public function add(){
        $setting = Setting::orderBy('id','asc')->first();
        
        $users = User::all();

        return view('services.create',['users'=>$users,'setting'=>$setting]);
    }

    public function store(Request $request){
        

            $validator = Validator::make($request->all(),[
                    'name'       => 'required',
                    'desc'       => 'required',
                    'date'       => 'required',
                    'salary_before'       => 'required',
                    'salary_after'       => 'required',
                    'by'       => 'required',
                    'img'       => 'required',
                    'img2'       => 'required',
                    'img3'       => 'required',
                    'location'       => 'required',
                    'duration'       => 'required',
                    'time'       => 'required',
                    

                 ]);

                 if($validator->fails())
                    {
                        
                        return redirect()->back();       
                    }
            $services = new Course;
            $services->name =$request['name'];
            $services->desc =$request['desc'];
            $services->date =$request['date'];
            $services->salary_before =$request['salary_before'];
            $services->salary_after =$request['salary_after'];
            $services->by =$request['by'];
            $services->location =$request['location'];
            $services->time =$request['time'];
            $services->duration =$request['duration'];
            $services->enrolled =$request['enrolled'];
                
          $images           = $request['img'];
          $images2           = $request['img2'];
          $images3           = $request['img3'];


                      if($images)
                {
                
                
                
                    $img_name = rand(0, 999) . '.' . $images->getClientOriginalExtension();
                    $images->move(base_path('public/dash2/assets/img'), $img_name);
                    
             

                
                $services->img = $img_name;
            }

                      if($images2)
                {
                
                
                
                    $img_name = rand(0, 999) . '.' . $images2->getClientOriginalExtension();
                    $images2->move(base_path('public/dash2/assets/img'), $img_name);
                    
             

                
                $services->img2 = $img_name;
            }
            

                      if($images3)
                {
                
                
                
                    $img_name = rand(0, 999) . '.' . $images3->getClientOriginalExtension();
                    $images3->move(base_path('public/dash2/assets/img'), $img_name);
                    
             

                
                $services->img3 = $img_name;
            }
            $services->save();
            if($services){
                return redirect()->route('Service.show');

            }
        
        return back();
    }

    public function edit($id){

        $setting = Setting::orderBy('id','asc')->first();
        $users = User::all();
        $service = Course::find($id);
        return view('services.edit',compact('service','users','setting'));
    }

    public function update(Request $request,$id)
    {
        
        
        

           if (Auth::check()){

            $services = Course::find($id);

        if($services)
        {

            $validator = Validator::make($request->all(),[
                    'name'       => 'required',
                    'desc'       => 'required',
                    'date'       => 'required',
                    'salary_before'       => 'required',
                    'salary_after'       => 'required',
                    'by'       => 'required',
                    'img'       => 'required',
                    'img2'       => 'required',
                    'location'       => 'required',
                    'duration'       => 'required',
                    'time'       => 'required',
                    

                 ]);

                 if($validator->fails())
                    {
                        
                        return redirect()->back();       
                    }
            
            $services->name =$request['name'];
            $services->desc =$request['desc'];
            $services->date =$request['date'];
            $services->salary_before =$request['salary_before'];
            $services->salary_after =$request['salary_after'];
            $services->by =$request['by'];
            $services->location =$request['location'];
            $services->duration =$request['duration'];
            $services->enrolled =$request['enrolled'];
            $services->time =$request['time'];
                
          $images           = $request['img'];
          $images2           = $request['img2'];
          $images3           = $request['img3'];


                      if($images)
                {
                
                
                
                    $img_name = rand(0, 999) . '.' . $images->getClientOriginalExtension();
                    $images->move(base_path('public/dash2/assets/img'), $img_name);
                    
             

                
                $services->img = $img_name;
            }

                      if($images2)
                {
                
                
                
                    $img_name = rand(0, 999) . '.' . $images2->getClientOriginalExtension();
                    $images2->move(base_path('public/dash2/assets/img'), $img_name);
                    
             

                
                $services->img2 = $img_name;
            }
            

                      if($images3)
                {
                
                
                
                    $img_name = rand(0, 999) . '.' . $images3->getClientOriginalExtension();
                    $images3->move(base_path('public/dash2/assets/img'), $img_name);
                    
             

                
                $services->img3 = $img_name;
            }
            $services->save();
            if($services){
                return redirect()->route('Service.show');

            }
        }
        return back();
    }
}



    public function search(Request $request)
    {
                $setting = Setting::orderBy('id','asc')->first();

    $searchcourse = Course::where('name', 'LIKE', '%' .$request['text']. '%')->paginate(2);
    
            return view('home.search',['searchcourse'=>$searchcourse,'setting'=>$setting]);

 
    }

    
     public function singleCourse(Request $request)
     {
        $id=$request->id;
        $setting = Setting::orderBy('id','asc')->first();
         $sliders = Slider::all();
         $course = Course::find($request->id);
        // dd($request->id);
         $reviews = Review::where('course_id',$request->id)->get();
        // dd($reviews);

         //echo dd(empty($reviews->items));
         // if(empty($reviews->items)){
            
         // }
         
          if ($id!=null) {
            

        return view('home.single_course',compact('course','reviews','sliders','setting','id'));
       }
       
       if(Auth::check() and $id=null){
       
       
        return redirect()->route('Course.showweb')->with(['fail' => 'تم فقد الصفحة لتأخرك برجاء الاختيار مجددا ']);
       }
        else{

             return redirect()->route('USER_LOGIN');

        }




        
    }



    public function mysingleCourse($id)
    {
        $setting = Setting::orderBy('id','asc')->first();
        if(Auth::check()){

         $sliders = Slider::all();
         $transfers =Transfer::all();
         $reservedcourses =ReservedCourses::all();
         $course = Course::find($id);
         $reviews = Review::where('course_id',$id)->get();
        return view('home.mysinglecourse',compact('reservedcourses','course','reviews','sliders','setting','transfers','id'));
    }
     else{

             return redirect()->route('USER_LOGIN');

        }

    }

     public function storeReview(Request $request){
         
         if(Auth::check()){
        $x=0;
        $reviewss = Review::orderBy('id','desc')->get();
         foreach ($reviewss as $reviews) {
            if ($reviews->course_id==$request['course_id'] and $reviews->user_id==$request['user_id']) {
                $x=1;
            }
         }
         $course = Course::find($request['course_id']);
         $setting = Setting::orderBy('id','asc')->first();
         $sliders = Slider::all();
         //dd(count($reviews));
        if (Auth::check() and $x==0){
             $reviews = new Review;
               $reviews->user_id = $request['user_id'];
                $reviews->course_id = $request['course_id'];
                $reviews->name = $request['name'];
                $reviews->review = $request['review'];
                $reviews->rating = $request['rating'];
                $reviews->save();
         
            if($reviewss){
               $reviews = Review::where('course_id',$request['course_id'])->get();
                return view('home.single_course',compact('course','reviews','sliders','setting'))->with(['success' => 'تم عمل تقييم ']);
                //return redirect()->back();
            }
            }
            else{   
               $reviews = Review::where('course_id',$request['course_id'])->get();

                return view('home.single_course',compact('course','reviews','sliders','setting'))->with(['fail' => 'تم عمل تقييم من قبل']);
    }}
    else{

             return redirect()->route('USER_LOGIN');

        }

    }

    public function rating()
    {
        $courses = Course::orderBy('id','dsec')->get();
        $Reviews = Review::orderBy('id','dsec')->get();
        foreach ($courses as $course) {
            $xx=0.0;
            $i=0;
        foreach ($Reviews as $Review) {  
            if ($Review->course_id==$course->id) {
                # code...
        $rating = $Review->rating;
        $xx =$xx+$rating;
        $i++;
            }
        }
        $rat=$xx/$i;
        //dd($rat);
         \DB::table('courses')
            ->where('id', $course->id)
            ->update(['rating' => $rat]);
    }

return back();


    }

    public function courseRegister(Request $request)
    {
        if(Auth::check()){
         $banks =Bank::all();
        $setting = Setting::orderBy('id','asc')->first();

         $i___d = $request->id;

        return view('home.course_register',compact('i___d','setting','banks'));
    }
    else{
        return redirect()->route('USER_LOGIN');
    }
    }

    public function storeCousre(Request $request){

        $setting = Setting::orderBy('id','asc')->first();
        if (Auth::check()){
        $Reservedcourse = new ReservedCourses ;
        $Reservedcourse->user_id =$request['user_id'];
        $Reservedcourse->course_id =$request['course_id'];
        $Reservedcourse->save();    
        $i___d=$request['course_id'];
    if($Reservedcourse){
                
        return redirect()->back()->with(['success' => 'تم التسجيل بنجاح ويجب الاحتفاظ بصورة التحويل']);
            }
            else{
                return redirect()->back()->with(['fail' => 'لم يتم التسجيل']);
            }
        }
        
            
    }

     public function showweb(Request $request){
        $setting = Setting::orderBy('id','asc')->first();
         
        $courses   = Course::orderBy('id','desc')->paginate(2);       
        return view('home.courses',['courses'=>$courses,'setting'=>$setting]);
    }
    public function mycoursess($id)
    {
        $setting = Setting::orderBy('id','asc')->first();
        if(Auth::check()){
        $users = User::all();
        $reservedcourses = ReservedCourses::where('user_id',$id)->orderBy('id')->paginate(2);
        return view('home.mycourses',['reservedcourses'=>$reservedcourses,'setting'=>$setting,'users'=>$users]);
        }
        else{
             return redirect()->route('USER_LOGIN');
        }

    }

    public function mycourses()
    {
        $setting = Setting::orderBy('id','asc')->first();
        if(Auth::check()){
        $users = User::all();
        $reservedcourses = ReservedCourses::where('user_id',Auth::User()->id)->orderBy('id')->paginate(2);
        return view('home.mycourses',['reservedcourses'=>$reservedcourses,'setting'=>$setting,'users'=>$users]);
        }
        else{
             return redirect()->route('USER_LOGIN');
        }

    }


    public function mysingleeCourse(Request $request)
    {
       $id=$request->id;
        $setting = Setting::orderBy('id','asc')->first();
        if(Auth::check()){
         $sliders = Slider::all();
         $transfers =Transfer::orderBy('course_id','asc')->where('course_id',$id)->where('user_id',Auth::User()->id)->get();

         //dd((empty($transfers[0]->id)));
         $reservedcourses =ReservedCourses::orderBy('course_id','asc')->where('course_id',$id)->get();

         $course = Course::find($request->id);
         $reviews = Review::where('course_id',$request->id)->get();
       if ($id!=null) {

        return view('home.mysinglecourse',compact('reservedcourses','course','reviews','sliders','setting','transfers','id'));
       }else{
        return redirect()->route('Course.mycourses')->with(['fail' => 'تم فقد الصفحة لتأخرك برجاء الاختيار مجددا ']);
       }
    }
     else{

             return redirect()->route('USER_LOGIN');

        }

    }
         public function gettransfer(Request $request){

             return view('home.message');
             
         }


     public function storetransfer(Request $request){
        $setting = Setting::orderBy('id','asc')->first();
        if (Auth::check()){
           

            $validator = Validator::make($request->all(),[
                    'img'       => 'required|image|mimes:jpeg,png,jpg,gif,svg|max:2048',
                 ]);

                 if($validator->fails())
                    {
                        
                        return redirect()->back();       
                    }

        $transfer = new Transfer ;
        $transfer->user_id =$request['user_id'];
        $transfer->course_id =$request['course_id'];
        $transfer->reserved_id =$request['reserved_id'];
        //dd($transfer);
        $images = $request['img'];

            if($images)
                {
                
                $img_name = rand(0, 999) . '.' . $images->getClientOriginalExtension();
                $images->move(base_path('public/dash2/assets/img'), $img_name);
                $transfer->img = $img_name;
            }
            
       $transfer->save();
       
       
       $data= Transfer::orderBy('id','desc')->first();

        
        Mail::send('home.message', $data,function($message) use ($data){
        $message->from('hamdyasaad107@gmail.com');
        $message->to('info@atiscenter.org');
        $message->attach($data['img']->getRealPath(),array(
            'as'=>'img' .$data['img']->getClientOriginalExtension(),
            'mime'=>$data['img']->getMimeType()
            
            ));
        
      });
      
      
        $i___d=$request['course_id'];
         $sliders = Slider::all();
         $id=$i___d;

         $transfers =Transfer::orderBy('course_id','asc')->where('course_id',$id)->where('user_id',Auth::User()->id)->get();

         //dd((empty($transfers[0]->id)));
         $reservedcourses =ReservedCourses::orderBy('course_id','asc')->where('course_id',$id)->get();

         $course = Course::find($id);
         //dd($course);
         $reviews = Review::where('course_id',$request->id)->get();
         

        


    if($transfer){
    return view('home.mysinglecourse',compact('reservedcourses','course','reviews','sliders','setting','transfers','id'));
            }
            
        }
        
            
    }


    


}
