<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Setting;
use App\Bank;
use Validator;
use App\Transfer;
use DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;



class BankController extends Controller
{
    public function show()
    {
    	$banks = Bank::all();
        $setting = Setting::orderBy('id','asc')->first();
    	return view('bank.show',compact('setting','banks'));
    }

     public function edit($id){
        $setting = Setting::orderBy('id','asc')->first();
        $bank = Bank::find($id);
        return view('bank.edit',compact('bank','setting'));
    }

     public function update(Request $request,$id)
    {
        
        
        

           if (Auth::check()){

            $banks = Bank::find($id);

        if($banks)
        {

            $validator = Validator::make($request->all(),[
                    'name'       => 'required',
                    'account_name'       => 'required',
                    'account_number'       => 'required',
                    'iban_number'       => 'required',
                    
                    

                 ]);

                 if($validator->fails())
                    {
                        
                        return redirect()->back();       
                    }
            
            $banks->name =$request['name'];
            $banks->account_name =$request['account_name'];
            $banks->account_number =$request['account_number'];
            $banks->iban_number =$request['iban_number'];
            
            
            $banks->save();
            if($banks){
                return redirect()->route('Bank.show');

            }
        }
        return back();
    }
}

public function transfer()
	{

        $setting = Setting::orderBy('id','asc')->first();
		$transfers = Transfer::all();
		return view('bank.transfer',compact('transfers','setting'));
	}

	public function Suspendshow($id)
    {
                 
                $upmember = Transfer::find($id);

            if(Input::has('status'))
            {
              if($upmember->status == 0)
              {
                DB::table('transfers')->where('id',$id)->update(['status' => 1]);
                return back();
              }
              else 
              {
                DB::table('transfers')->where('id',$id)->update(['status' => 0]);
                return back();
              }
            }
        }
}
