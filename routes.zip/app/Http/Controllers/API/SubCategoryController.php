<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Sub_category;
use App\Category;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

use JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;

class SubCategoryController extends Controller
{
    public function create(Request $request)
    {
        $validator = Validator::make($request->all() , [
            'title'=>'required',
            'cat_id'=>'required'


        ]);
        if ($validator->passes()){
            $sub_category = new Sub_category();
            $sub_category->title = $request['title'];
            $sub_category->cat_id = $request['cat_id'];


            $sub_category->save();

            return response()->json(['value'=>true,'msg'=>'sub_category created']);
        }else{
            return response()->json(['value'=>false,'msg'=>$validator->errors()]);
        }
    }
    public function update($id,Request $request){
        $sub_category = Sub_category::findOrFail($id);
        if ($sub_category){
            $sub_category->title = $request['title'];
            $sub_category->Category->title = $request['cat_id'];



            $sub_category->update();
            return response()->json(['value'=>true,'msg'=>'sub_category updated']);
        }else{
            return response()->json(['value'=>false,'msg'=>'wrong id']);
        }
    }
    public function destroy($id){
        Sub_category::destroy($id);
        return response()->json(['value'=>true,'msg'=>'sub_category deleted']);
    }
}
