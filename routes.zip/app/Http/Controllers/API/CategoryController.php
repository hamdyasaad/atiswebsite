<?php

namespace App\Http\Controllers\Api;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

use App\Category;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

use JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;

class CategoryController extends Controller
{
    public function create(Request $request)
    {
        $validator = Validator::make($request->all() , [
            'title'=>'required',


        ]);
        if ($validator->passes()){
            $category = new Category();
            $category->title = $request['title'];

            $category->save();

            return response()->json(['value'=>true,'msg'=>'category created']);
        }else{
            return response()->json(['value'=>false,'msg'=>$validator->errors()]);
        }
    }
    public function update($id,Request $request){
        $category = Category::findOrFail($id);
        if ($category){
            $category->title = $request['title'];
            $category->update();
            return response()->json(['value'=>true,'msg'=>'category updated']);
        }else{
            return response()->json(['value'=>false,'msg'=>'wrong id']);
        }
    }
    public function destroy($id){
        Category::destroy($id);
        return response()->json(['value'=>true,'msg'=>'category deleted']);
    }
}
