<?php

namespace App\Http\Controllers\API;
use App\Service;
use App\KeyWord;
use App\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

use JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;

class ServiceController extends Controller
{
    public function create(Request $request)
    {
        $validator = Validator::make($request->all() , [
            'title'=>'required',
            'cat_id'=>'required',
            'salary' =>'required',
            'deadline_time' =>'required',
            'desc' =>'required',
            'customer_help' =>'required',
            'owner_id' =>'required',
            'order_count' =>'required',
            'key_id' =>'required',


        ]);
        if ($validator->passes()){
            $service = new Service();
            $service->title = $request['title'];
            $service->cat_id = $request['cat_id'];
            $service->salary = $request['salary'];
            $service->deadline_time = $request['deadline_time'];

            $service->desc = $request['desc'];
            $service->customer_help = $request['customer_help'];
            $service->owner_id = $request['owner_id'];
            $service->order_count = $request['order_count'];
            $service->key_id = $request['key_id'];

            $service->save();
            $data['title'] = $service->title;
            return response()->json(['value'=>true,'msg'=>'service created','data'=>$data]);
        }else{
            return response()->json(['value'=>false,'msg'=>$validator->errors()]);
        }
    }
    public function update($id,Request $request){
        $service = Service::findOrFail($id);
        if ($service){
            $service->title = $request['title'];
            $service->Category->title = $request['cat_id'];
            $service->salary = $request['salary'];
            $service->deadline_time = $request['deadline_time'];
            $service->desc = $request['desc'];
            $service->customer_help = $request['customer_help'];
            $service->owner_id = $request['owner_id'];
            $service->order_count = $request['order_count'];
            $service->KeyWord->title = $request['key_id'];
            $service->update();

            return response()->json(['value'=>true,'msg'=>'service updated']);
        }else{
            return response()->json(['value'=>false,'msg'=>'wrong id']);
        }
    }
    public function destroy($id){
        Service::destroy($id);
        return response()->json(['value'=>true,'msg'=>'service deleted']);
    }
}
