<?php

namespace App\Http\Controllers\API;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\User;

use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;

use JWTAuth;
use Tymon\JWTAuth\Exceptions\JWTException;

class AdminController extends Controller
{
    public function authenticate(Request $request)
    {
        $credentials = $request->only('email', 'password');

        try {
            if (! $token = JWTAuth::attempt($credentials)) {
                return response()->json(['error' => 'invalid_credentials'], 400);
            }
        } catch (JWTException $e) {
            return response()->json(['error' => 'could_not_create_token'], 500);
        }

        return response()->json(compact('token'));
    }

    public function register(Request $request)
    {
        $validator = Validator::make($request->all(), [
            'user_name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:6|confirmed',
            'first_name' => 'required',
            'last_name' => 'required'
        ]);

        if($validator->fails()){
            return response()->json($validator->errors()->toJson(), 400);
        }

        $user = User::create([
            'user_name' => $request->get('user_name'),
            'email' => $request->get('email'),
            'password' => Hash::make($request->get('password')),


            'first_name' => $request->get('first_name'),
            'last_name' => $request->get('last_name'),

        ]);

        $token = JWTAuth::fromUser($user);

        return response()->json(compact('user','token'),201);
    }

    public function getAuthenticatedUser()
    {
        try {

            if (! $user = JWTAuth::parseToken()->authenticate()) {
                return response()->json(['user_not_found'], 404);
            }

        } catch (Tymon\JWTAuth\Exceptions\TokenExpiredException $e) {

            return response()->json(['token_expired'], $e->getStatusCode());

        } catch (Tymon\JWTAuth\Exceptions\TokenInvalidException $e) {

            return response()->json(['token_invalid'], $e->getStatusCode());

        } catch (Tymon\JWTAuth\Exceptions\JWTException $e) {

            return response()->json(['token_absent'], $e->getStatusCode());

        }

        return response()->json(compact('user'));
    }

    public function create(Request $request)
    {
        $validator = Validator::make($request->all() , [
            'user_name'=>'required',
            'email'=>'required',
            'password' =>'required',
            'first_name' =>'required',
            'last_name' =>'required',

        ]);
        if ($validator->passes()){
            $user = new User();
            $user->user_name = $request['user_name'];
            $user->email = $request['email'];
            $user->password = $request['password'];
            $user->first_name = $request['first_name'];
            $user->last_name = $request['last_name'];
            $user->save();
            $data['user_name'] = $user->user_name;
            return response()->json(['value'=>true,'msg'=>'user created','data'=>$data]);
        }else{
            return response()->json(['value'=>false,'msg'=>$validator->errors()]);
        }
    }
    public function update($id,Request $request){
        $user = User::findOrFail($id);
        if ($user){
            $user->user_name = $request['user_name'];
            $user->email=$request['email'];
            $user->password=$request['password'];
            $user->first_name=$request['first_name'];
            $user->last_name=$request['last_name'];

            $user->update();
            return response()->json(['value'=>true,'msg'=>'user updated']);
        }else{
            return response()->json(['value'=>false,'msg'=>'wrong id']);
        }
    }
    public function show(){
        $users = User::all();
        if (count($users) >=1){
            $data = [];
            foreach ($users as $user){
                $arr['name'] = $user->user_name;
                $arr['price'] = $user->email;
                $arr['password'] = $user->password;
                $arr['first_name'] = $user->first_name;
                $arr['last_name'] = $user->last_name;
                $data[]=$arr;
            }
            return response()->json(['value'=>true,'data'=>$data]);
        }else{
            return response()->json(['value'=>false,'msg'=>'wrong']);
        }
    }
    public function destroy($id){
        User::destroy($id);
        return response()->json(['value'=>true ,'msg'=>'user deleted']);
    }







}
