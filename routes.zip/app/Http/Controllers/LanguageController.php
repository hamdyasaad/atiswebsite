<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Contracts\Session\Session;
use Illuminate\Support\Facades\Auth;
use App\User;
use DB;


class LanguageController extends Controller
{
    public function getChangeLanguage($lang){
        if ($lang == 'en' || $lang == 'ar'){
            if (!\Session::has('language')){
                \Session::put('language',$lang);
            }else{
                \Session::put('language',$lang);

}
            return redirect()->back();
        }else{
            return redirect()->route('Dashboard');

        }
    }
}
