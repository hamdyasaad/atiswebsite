<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Setting;
use App\City;
use Validator;
use App\Transfer;
use DB;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Input;



class CityController extends Controller
{
    public function show()
    {
    	$cities = City::all();
        $setting = Setting::orderBy('id','asc')->first();
    	return view('cities.show',compact('setting','cities'));
    }

     public function edit($id){
        $setting = Setting::orderBy('id','asc')->first();
        $city = City::find($id);
        return view('cities.edit',compact('city','setting'));
    }

     public function update(Request $request,$id)
        {
           if (Auth::check()){

            $cities = City::find($id);

        if($cities)
        {

            $validator = Validator::make($request->all(),[
                    'arname'       => 'required',
                    'enname'       => 'required',
                    
                    
                    

                 ]);

                 if($validator->fails())
                    {
                        
                        return redirect()->back();       
                    }
            
            $cities->arname =$request['arname'];
            $cities->enname =$request['enname'];

            
            
            
            $cities->save();
            if($cities){
                return redirect()->route('City.show');

            }
        }
        return back();
    }
}

public function add(){
        $setting = Setting::orderBy('id','asc')->first();
        

        return view('cities.create',['setting'=>$setting]);
    }
    
       public function store(Request $request){
        

            $validator = Validator::make($request->all(),[
                    'arname'       => 'required',
                    'enname'       => 'required',
                   
                    

                 ]);

                 if($validator->fails())
                    {
                        
                        return redirect()->back();       
                    }
            $cities = new City;
            $cities->arname =$request['arname'];
            $cities->enname =$request['enname'];
           
            $cities->save();
            if($cities){
                return redirect()->route('City.show');

            }
        
        return back();
    }

  public function deleteService($id){
        City::destroy($id);
        return back();
    }
}
