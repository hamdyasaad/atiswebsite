<?php

namespace App\Http\Controllers;


use Illuminate\Support\Facades\Auth;

use App\Review;
use App\Course;
use App\User;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class CategoryController extends Controller
{


    public function show()
    {
        $courses = Course::all();
        $users = User::all();
        $categories = Review::all();
        return view('categories.show', ['categories'=>$categories,'courses'=>$courses,'users'=>$users]);
    }


    public function add(){

        return view ('categories.create');

    }
    public function store(Request $request)
    {
        $category= new Category();
        $category->title = $request['tilte'];
        $category->save();

        return view('categories.show');

    }
    public function deleteCATEGORY($id){
        Category::destroy($id);
        return back();
    }
    public function edit($id){
        $category = Category::find($id);
        return view('categories.edit',compact('category'));
    }

    public function update(Request $request,$id)
    {
        Category::find($id)->update([
            'title'=>$request->input('title')

        ]);


        return redirect()->route('Category.show');
    }


}
