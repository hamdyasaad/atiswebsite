<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Goal;
use App\Setting;

class GoalController extends Controller
{
     public function show(){
        $setting = Setting::orderBy('id','asc')->first();

     	$goals = Goal::all();
        return view('home.goal',compact('goals','setting'));
    }


     public function showadmin(){
        $setting = Setting::orderBy('id','asc')->first();

     	     	$goals = Goal::all();

        return view('goals.goal',compact('goals','setting'));
    }

     public function edit($id){
        $setting = Setting::orderBy('id','asc')->first();
        $goal = Goal::find($id);
        return view('goals.edit',compact('goal','setting'));
    }

     public function update(Request $request,$id)
    {
        Goal::find($id)->update([
            'endesc'=>$request->input('endesc'),
            'ardesc'=>$request->input('ardesc'),
            



        ]);


        return redirect()->back();
    }
}
