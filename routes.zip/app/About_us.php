<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class About_us extends Model
{
    //
}
