<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Customer_order extends Model
{
    protected $table  = 'customer_orders';
    protected $fillable = ['service_id','user_id','status'];
}
