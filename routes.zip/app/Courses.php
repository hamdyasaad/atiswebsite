<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Course extends Model
{
   protected $table='courses';

    protected $fillable=['name','img','desc','include','views','date','rate','salary_before','salary_after','by','review','location','duration','time','enrolled','owner_id','first_name', 'last_name', 'age','gender','country','city','address1','address2','email','mobile','payment','bank_name','account_name','account_number','iban_number'];

    public function Owner()
    {
        return $this->belongsTo(User::class, 'owner_id');
    }

     public function Reserveuser()
    {
    return $this->belongsToMany('App\User','reserved_courses')->withTimestamps();
    }
    public function CTransfer()
    {
    return $this->belongsToMany('App\User','transfers')->withTimestamps();
    }

    public function Customers()
    {
        return $this->belongsToMany(User::class, 'reviews', 'course_id', 'user_id');
    }
       public function Cuser()
    {
        return $this->belongsTo(User::class, 'owner_id');
    }

    public function Category()
    {
        return $this->belongsTo(Sub_category::class, 'cat_id');
    }

    public function KeyWord()
    {
        return $this->belongsTo(KeyWord::class, 'key_id');
    }

     public function Banks()
    {
        return $this->hasMany(Bank::class, 'course_id');
    }

    public function Images()
    {
        return $this->hasMany(Service_images::class, 'service_id');
    }

    public function ExtraServices()
    {
        return $this->hasMany(ExtraService::class, 'service_id');
    }

      public function Users()
    {
        return $this->belongsToMany('App\User','reviews')->withTimestamps();
    }

}
