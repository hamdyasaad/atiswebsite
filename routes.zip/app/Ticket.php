<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Ticket extends Model
{
    protected $table='tickets';
    protected $fillable=['number','start_date','attendance','amount','amount_owed','name','duration','location','status'];
}
